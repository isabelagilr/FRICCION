<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
date_default_timezone_set('America/La_Paz');
session_start();

include 'conexion.php';

$link = Conectarse();


?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <title>Registro de personas</title>

        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- librerías opcionales que activan el soporte de HTML5 para IE8 -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
         <div class="row">
            <div class="col-lg-12 col-sm-8">
                <nav class="navbar navbar-default" role="navigation">
                    <div class="container-fluid">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" 
                                    data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand" href="bienvenida.php">FRICCION</a>
                        </div>
                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul class="nav navbar-nav">
                                
                                <li><a href="#">MAQUINAS</a></li>         
                                <li><a href="#">CATEGORIAS</a></li>
                                 <li><a href="#">ESTADOS</a></li>
                                  <li><a href="#">ALMACENES</a></li>
                                   <li><a href="#">PRODUCTOS</a></li>
                                   
                                    <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" 
                                       aria-expanded="false">MOVIMIENTOS<span class="caret"></span>
                                    </a>
                                   <ul class="dropdown-menu" role="menu">
                                        <li><a href="#">Registrar</a></li>
                                            <li class="divider"></li>
                                        <li><a href="movimientose.php">Entradas</a></li>
                                            <li class="divider"></li>
                                        <li><a href="movimientoss.php">Salidas</a></li>
                                    </ul>
                                    </li>
                                    
                                    <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" 
                                       aria-expanded="false">CONTEO<span class="caret"></span>
                                    </a>
                                    <ul class="dropdown-menu" role="menu">
                                        <li><a href="conteo.php">Registar</a></li>
                                            <li class="divider"></li>
                                    </ul>
                                    </li>
                                    
                                      <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" 
                                       aria-expanded="false">INFORMES <span class="caret"></span>
                                    </a>
                                    <ul class="dropdown-menu" role="menu">
                                        <li><a href="infome_movimiento.php">Informe de movimientos</a></li>
                                            <li class="divider"></li>
                                        <li><a href="informe_capital.php">Informe de capital</a></li>
                                    </ul>
                                    </li>
                                
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" 
                                       aria-expanded="false">USUARIOS <span class="caret"></span>
                                    </a>
                                    <ul class="dropdown-menu" role="menu">
                                        <li><a href="personas.php">Personas</a></li>
                                    </ul>
                                </li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                        <?php echo $_SESSION['usuario']; ?> <span class="caret"></span>
                                    </a>
                                    <ul class="dropdown-menu" role="menu">
                                        <li><a href="#">Ver Perfil</a></li>
                                        <li><a href="#"> Cambiar Clave</a></li>
                                        <li class="divider"></li>
                                        <li><a href="salir">Cerrar Sesion</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div><!-- /.navbar-collapse -->
                    </div><!-- /.container-fluid -->
                </nav>
            </div>
        </div>

        <div id="wrapper">
            <div class="container">

                <div class="row" id="NuevoRegistro">
                    <div class="col-lg-6 col-sm-6">
                        <form action="" method="post">
                            <div class="form_description">
                                <h2>Resgistro de Movimientos</h2>
                                <p>Registros de entradas y salidas.</p>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="movimiento">Id Movimiento </label>
                                        <input id="movimiento" name="movimiento" class="form-control" type="text" value="" disabled=""/> 
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="fecha">Fecha </label>
                                        <input id="fecha" name="fecha" class="form-control" type="text" value="<?php echo date('Y-m-d'); ?>" disabled/> 
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label for="encargado">Encargado </label>
                                            <input id="encargado" name="encargado" class="form-control" type="text" value="<?php echo $_SESSION['usuario']; ?>" disabled/> 
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="hora">Hora </label>
                                        <input id="hora" name="hora" class="form-control" type="text" value="<?php echo date('G:i:s'); ?>" disabled/> 
                                    </div>
                                </div>
                            </div>
                            <div class="divider">Detalles del ingreso al almacen</div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="almacen">Almacen </label>
                                        <select name="almacen" class="form-control">
                                            <option value="1">central</option>
                                          
                                        </select>
                                    </div>
                                </div>
                              
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="producto">Producto </label>
                                        <input id="producto" name="producto" class="form-control" type="text" value="" required/> 
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6"> 
                                    <div class="form-group">
                                        <label for="tipomov">Tipo de movimiento </label>
                                        <input id="tipomov" name="tipomov" class="form-control" type="text" value="Entrada" disabled /> 
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label  for="cantidad">Cantidad </label>
                                        <input id="cantidad" name="catidad" class="form-control" type="text" value="" required/> 
                                    </div>
                                </div> 
                            </div>
                            <div class="divider">Datos del producto</div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="costo">Costo </label>
                                        <input id="costo" name="costo" class="form-control" type="text" value="" required/> 
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="estado">Estado </label>
                                        <select name="estado" class="form-control">
                                            <option value="1">Nuevo</option>
                                            <option value="2">Usado</option>
                                            <option value="2">Reparado</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6"> 
                                    <div class="form-group">
                                        <label for="nombreprov">Nombre provedor </label>
                                        <input id="nombreprov" name="nombreprov" class="form-control" type="text" value="" required /> 
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label  for="ubicacion">Ubicacion </label>
                                        <input id="ubicacion" name="ubicacion" class="form-control" type="text" value="" required/> 
                                    </div>
                                </div> 
                            </div>
                           
                            <input id="saveForm" class="btn btn-primary" type="submit" name="Guardar" value="Guardar" />
                        </form>	
                    </div>
                </div>
                <?php
                
   
            if($_POST['Guardar'])
          {
                
                $fecha=$_POST['fecha'];
                $encargado=$_POST['encargado'];
                $hora=$_POST['hora'];
                $almacen=$_POST['almacen'];
                $producto=$_POST['producto'];
                $tipomov=$_POST['tipomov'];
                $cantidad=$_POST['cantidad'];
                $costo=$_POST['costo'];
                $estado=$_POST['estado'];
                $nombreprov=$_POST['nombreprov'];
                $ubicacion=$_POST['ubicacion'];
                
                $sql=" INSERT INTO `tbmovimiento`(`fecha`, `idencargado`, `hora`, `idalmacen`, `idproducto`, `tipomovimiento`, `cantidad`) VALUES ("
                        ."'".$fecha."','".$encargado."','".$hora."','".$almacen."',".$producto.",'".$tipomov."','".$cantidad."')";
                echo $sql;
                $result = mysqli_query($link,$sql);
                if($result){
                    header("Location: movimientose.php");
                    echo "<div class=\"alert alert-success\">Registro exitoso</div>";
                }else{
                    echo "<div class=\"alert alert-danger\">".mysqli_errno($link) ." - ". mysqli_error($link)."</div>";
                }
                
                 $sql2=" INSERT INTO `tbentrada`(`costo`, `provedor`, `ubicacionenalmacen`, `idestadoproducto`) VALUES ("
                        ."'".$costo."','".$nombreprov."','".$ubicacion."')";
                echo $sql2;
                $result2 = mysqli_query($link,$sql2);
                if($result2){
                    header("Location: personas.php");
                    echo "<div class=\"alert alert-success\">Registro exitoso</div>";
                }else{
                    echo "<div class=\"alert alert-danger\">".mysqli_errno($link) ." - ". mysqli_error($link)."</div>";
                }
            }
        ?>
              
            </div>
        </div>

        <!-- Librería jQuery requerida por los plugins de JavaScript -->
        <script src="js/jquery-1.11.1.min.js"></script>
        <!-- Todos los plugins JavaScript de Bootstrap (también puedes
             incluir archivos JavaScript individuales de los únicos
             plugins que utilices) -->
        <script src="js/bootstrap.min.js"></script>
    </body>
</html>
