

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

   <?php
                
           if ($_POST['Guardar']) {

                    $nombre = $_POST['nombre'];
                    $apellidoP = $_POST['appaterno'];
                    $apellidoM = $_POST['apmaterno'];
                    $cargo = $_POST['cargo'];
                    $telefono = $_POST['telefono'];
                    $email = $_POST['email'];


                    $sql = " INSERT INTO `tbpersona`(`nombres`, `apellidopaterno`, `apellidomaterno`, `cargo`, `telefono`, `email`) VALUES ("
                            . "'" . $nombre . "','" . $apellidoP . "','" . $apellidoM . "','" . $cargo . "'," . $telefono . ",'" . $email . "')";
                    //echo $sql;
                    $result = mysqli_query($link, $sql);
                    if ($result) {
                        header('Location: /personas.php');
                        //echo "<div class=\"alert alert-success\">Registro exitoso</div>";
                    } else {
                        echo "<div class=\"alert\">";
                        echo "<div class=\"alert alert-danger\">" . mysqli_errno($link) . " - " . mysqli_error($link) . "</div>";
                        echo "</div>";
                    }
                }
                mysqli_close($link);

                ?>